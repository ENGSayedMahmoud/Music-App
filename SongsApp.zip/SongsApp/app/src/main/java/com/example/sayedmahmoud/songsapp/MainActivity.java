package com.example.sayedmahmoud.songsapp;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final List<DataModel> singerList = new ArrayList<>();
        singerList.add(new DataModel("Amr Diab",R.drawable.amr));
        singerList.add(new DataModel("Pop",R.drawable.pop));
        singerList.add(new DataModel("Armin Van Burin",R.drawable.armin));
        singerList.add(new DataModel("Sia",R.drawable.sia));



        DataModelAdaptor viewadaptor = new DataModelAdaptor(this, singerList);
        ListView listView = findViewById(R.id.list_view_singers);

        listView.setAdapter(viewadaptor);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                //DataModel singer = singerList.get(i);

                    Intent intent = null;
                    switch(position){
                        case 0:
                            intent = new Intent(getApplicationContext(), PageOne.class);
                            break;
                        case 1:
                            intent = new Intent(getApplicationContext(), PageTwo.class);
                            break;
                        case 2:
                            intent = new Intent(getApplicationContext(), PageThree.class);
                            break;
                        case 3:
                            intent = new Intent(getApplicationContext(), PageFour.class);
                            break;

                    }

                    if(intent != null){
                        startActivity(intent);
                    }



            }
        });


    }
}
